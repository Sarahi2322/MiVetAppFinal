// modelo/add_mascotas.js
import { createClient } from 'https://cdn.jsdelivr.net/npm/@supabase/supabase-js/+esm';
import { requireLogin, initRoleUI, isVet } from '../controlador/seguridad.js';

// --- Seguridad / sesión ---
const usuario = requireLogin(['Administrador', 'Recepcionista', 'Veterinario']);
initRoleUI(usuario);

// Solo el veterinario será solo lectura.
// Recepcionista y Administrador pueden editar todo.
const esSoloLectura = isVet(usuario);

// --- Supabase ---
const sb = createClient(window.SUPABASE_URL, window.SUPABASE_ANON_KEY);

// --- Helpers DOM ---
const $ = (s) => document.querySelector(s);

// Elementos del formulario (IDs según TU HTML)
const form        = $('#frmMascota');
const btnGuardar  = form?.querySelector('button[type="submit"]');

const inpId          = $('#id');
const inpNombre      = $('#nombre');
const inpEdadAnios   = $('#edad_anios');
const inpEdadMeses   = $('#edad_meses');
const selEspecie     = $('#especie');
const selRaza        = $('#raza');
const inpPesoKg      = $('#peso_kg');
const inpColor       = $('#color');
const inpDuenioTel   = $('#duenio_tel');     // cli_tel en la BD
const txtDiagnostico = $('#observaciones');  // mapeado a columna diagnostico
const txtTratamiento = $('#tratamiento');

const inpFoto        = $('#foto');
const imgPrevFoto    = $('#prevFoto');       // solo preview local

// Para manejar razas en memoria
let todasLasRazas = [];

// Obtener id de la mascota desde la URL (modo editar)
const params      = new URLSearchParams(window.location.search);
const idMascotaQS = params.get('id');

// --- Solo lectura para veterinario ---
function aplicarSoloLectura() {
  if (!esSoloLectura || !form) return;

  const campos = form.querySelectorAll('input, select, textarea');
  campos.forEach(c => {
    if (c.id === 'id') return; // el id oculto se deja
    c.disabled = true;
  });

  if (btnGuardar) {
    btnGuardar.style.display = 'none';
  }
}

// ================== RAZAS / ESPECIES ==================
function poblarEspecies() {
  if (!selEspecie) return;

  selEspecie.innerHTML = '<option value="">-- Selecciona especie --</option>';

  const especiesUnicas = [...new Set(todasLasRazas.map(r => r.especie))];

  for (const esp of especiesUnicas) {
    const opt = document.createElement('option');
    opt.value = esp;
    opt.textContent = esp;
    selEspecie.appendChild(opt);
  }
}

function poblarRazasPorEspecie(especieSeleccionada) {
  if (!selRaza) return;

  selRaza.innerHTML = '<option value="">Selecciona raza</option>';

  if (!especieSeleccionada) {
    selRaza.disabled = true;
    return;
  }

  const razasFiltradas = todasLasRazas.filter(r => r.especie === especieSeleccionada);

  for (const r of razasFiltradas) {
    const opt = document.createElement('option');
    opt.value = r.id;        // id de la tabla razas
    opt.textContent = r.nombre || `Raza #${r.id}`;
    selRaza.appendChild(opt);
  }
  selRaza.disabled = false;
}

async function cargarRazas() {
  try {
    // Primero probamos con "Razas"
    let res = await sb
      .from('Razas')
      .select('id, especie, nombre')
      .order('especie', { ascending: true })
      .order('nombre', { ascending: true });

    // Si falla (tabla no existe con ese nombre), probamos "razas"
    if (res.error) {
      console.warn('Fallo Razas, probando con razas:', res.error);
      res = await sb
        .from('razas')
        .select('id, especie, nombre')
        .order('especie', { ascending: true })
        .order('nombre', { ascending: true });
    }

    if (res.error) {
      console.error('Error cargando razas:', res.error);
      throw res.error;
    }

    todasLasRazas = res.data || [];
    poblarEspecies();
  } catch (err) {
    console.error('Error cargando razas (revisa nombre de tabla):', err);
    alert('No se pudieron cargar las razas.');
  }
}


// ================== CARGAR MASCOTA (EDITAR) ==================
async function cargarMascota(id) {
  console.log('cargarMascota con id =', id);

  const idNum = Number(id);
  const filtro = Number.isFinite(idNum) ? idNum : id;

  try {
    const { data, error } = await sb
      .from('mascotas')
      .select(`
        id,
        nombre,
        edad_anios,
        edad_meses,
        peso_kg,
        color,
        cli_tel,
        raza_id,
        observaciones,
        tratamiento,
        diagnostico,
        foto_url
      `)
      .eq('id', filtro)
      .maybeSingle();

    if (error) {
      console.error('Error cargando mascota:', error);
      throw error;
    }

    if (!data) {
      alert('No se encontró la mascota especificada.');
      return;
    }

    console.log('Mascota cargada:', data);

    // Rellenar campos básicos
    inpId.value          = data.id ?? '';
    inpNombre.value      = data.nombre ?? '';
    inpEdadAnios.value   = data.edad_anios ?? '';
    inpEdadMeses.value   = data.edad_meses ?? '';
    inpPesoKg.value      = data.peso_kg ?? '';
    inpColor.value       = data.color ?? '';
    inpDuenioTel.value   = data.cli_tel ?? '';
    txtDiagnostico.value = data.diagnostico ?? data.observaciones ?? '';
    txtTratamiento.value = data.tratamiento ?? '';

    // Foto (solo mostrar si hay URL)
    if (data.foto_url && imgPrevFoto) {
      imgPrevFoto.src = data.foto_url;
      imgPrevFoto.style.display = 'block';
    }

    // Especie y raza a partir de razas
    if (data.raza_id && todasLasRazas.length > 0) {
      const raza = todasLasRazas.find(r => Number(r.id) === Number(data.raza_id));
      if (raza) {
        selEspecie.value = raza.especie;
        poblarRazasPorEspecie(raza.especie);
        selRaza.value = data.raza_id;
      } else {
        console.warn('No se encontró la raza para raza_id =', data.raza_id);
      }
    }
  } catch (err) {
    console.error('Error cargando los datos de la mascota:', err);
    alert('No se pudieron cargar los datos de la mascota.');
  }
}

// ================== GUARDAR (INSERT / UPDATE) ==================
async function guardarMascota(evt) {
  evt.preventDefault();

  if (esSoloLectura) {
    alert('No tienes permisos para editar esta mascota.');
    return;
  }

  const payload = {
    nombre:       inpNombre.value.trim() || null,
    raza_id:      selRaza.value ? Number(selRaza.value) : null,
    edad_anios:   inpEdadAnios.value ? Number(inpEdadAnios.value) : null,
    edad_meses:   inpEdadMeses.value ? Number(inpEdadMeses.value) : null,
    peso_kg:      inpPesoKg.value ? Number(inpPesoKg.value) : null,
    color:        inpColor.value.trim() || null,
    cli_tel:      inpDuenioTel.value.trim() || null,
    diagnostico:  txtDiagnostico.value.trim() || null,
    tratamiento:  txtTratamiento.value.trim() || null
    // observaciones: podrías usarlo si quieres, pero no hay campo en el form
  };

  // Validaciones básicas
  if (!payload.nombre) {
    alert('El nombre de la mascota es obligatorio.');
    inpNombre.focus();
    return;
  }

  if (!payload.edad_anios && payload.edad_anios !== 0) {
    alert('La edad en años es obligatoria.');
    inpEdadAnios.focus();
    return;
  }

  if (!payload.raza_id) {
    alert('Debes seleccionar una especie y una raza.');
    selEspecie.focus();
    return;
  }

  if (!payload.cli_tel) {
    alert('Debes capturar el teléfono del dueño.');
    inpDuenioTel.focus();
    return;
  }

  let error;

  try {
    if (idMascotaQS) {
      const idNum = Number(idMascotaQS);
      const filtro = Number.isFinite(idNum) ? idNum : idMascotaQS;

      const { error: errUpdate } = await sb
        .from('mascotas')
        .update(payload)
        .eq('id', filtro);

      error = errUpdate;
    } else {
      const { error: errInsert } = await sb
        .from('mascotas')
        .insert(payload);

      error = errInsert;
    }

    if (error) {
      console.error('Error guardando mascota:', error);
      alert('Ocurrió un error al guardar la mascota.');
      return;
    }

    alert('Mascota guardada correctamente.');
    window.location.href = 'mascotas.html';
  } catch (err) {
    console.error('Error inesperado al guardar mascota:', err);
    alert('Ocurrió un error al guardar la mascota.');
  }
}

// ================== PREVIEW DE FOTO (OPCIONAL) ==================
if (inpFoto && imgPrevFoto) {
  inpFoto.addEventListener('change', () => {
    const file = inpFoto.files?.[0];
    if (!file) {
      imgPrevFoto.style.display = 'none';
      imgPrevFoto.src = '';
      return;
    }
    const reader = new FileReader();
    reader.onload = e => {
      imgPrevFoto.src = e.target.result;
      imgPrevFoto.style.display = 'block';
    };
    reader.readAsDataURL(file);
  });
}

// ================== EVENTOS ==================
if (form) {
  form.addEventListener('submit', guardarMascota);
}

if (selEspecie) {
  selEspecie.addEventListener('change', () => {
    poblarRazasPorEspecie(selEspecie.value);
  });
}

// ================== INIT ==================
(async function init() {
  try {
    console.log('Init add_mascotas, idMascotaQS =', idMascotaQS);

    await cargarRazas();

    if (idMascotaQS) {
      await cargarMascota(idMascotaQS);
    }
  } catch (e) {
    console.error('Error en init de add_mascotas:', e);
  } finally {
    aplicarSoloLectura();
  }
})();
